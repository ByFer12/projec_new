/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */
package com.client;

import com.client.vistas.VistaCliente;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.util.Scanner;


/**
 *
 * @author fer
 */
public class Cliente {

    public static void main(String[] args) {
        VistaCliente v=new VistaCliente();
        v.setVisible(true);
        v.setLocationRelativeTo(null);
        
    }
    
    public static void pruebas(){
                Scanner en = new Scanner(System.in);
   
    }
}
